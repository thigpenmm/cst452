<?php
session_start();
require 'database.php';

// creating variables
$id = $_SESSION['USER_ID'];
$title = $_GET['title'];
$author = $_GET['author'];
$genre = $_GET['genre'];
$summary = $_GET['summary'];
$book_pic = $_GET['book_pic'];


//inserts updated data into database (profile)
$sql_statement_books= "INSERT INTO `books` ( `title`, `author`, `genre`, `summary`, `book_pic`) VALUES ('$title', '$author', '$genre', '$summary', '$book_pic')";

if (mysqli_query($dbconn, $sql_statement_books)) {
	header("Location:bookList.php");
} else {
	echo "Error: " . $sql_statement_books . "<br>" . mysqli_error($dbconn);//error if connection fails
}



?>