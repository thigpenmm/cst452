<!--  Post class with methods for updated and retrieving posts -->
<?php
session_start();


class Post
{
	public function create_post($userid, $data)
	{
			
		require('database.php');
		
		$post = addslashes($data['userpost']);
		$username = $_SESSION['username'];
		$pic = $_SESSION['profilePic'];
		
		//inserts new data into database (posts)
		$sql_statement = "INSERT INTO `posts` (`post_id`, `date`, `user_id`, `post`, `image`, `comments`, `likes`, `username`, `profile_pic`)
		 VALUES (NULL, NULL, '$userid', '$post', NULL, 0, 0,'$username', '$pic' );";
		
		if (mysqli_query($dbconn, $sql_statement)) {
			
			header("Location: profile.php");
			
		} else {
			echo "Error: " . $sql_statement . "<br>" . mysqli_error($dbconn);//error if connection fails
		}
			
		}

	public function get_posts($id)
	{
		require('database.php');

		$sql_statement_posts = "SELECT * FROM `posts`";
		
			$result_posts = mysqli_query($dbconn, $sql_statement_posts);
			if($result_posts) {
				while ($row = mysqli_fetch_assoc($result_posts)) {
					$post = $row['post'];
					$date = $row['date'];
					$pic = $row ['profile_pic'];
				}
			}
		 else {
			echo "error connecting" . mysqli_connect_error();
		}

	}
	
	public function like_post($id, $type, $username){
		if($type == "post"){
			
			$sql_statement_likes = "UPDATE `posts` set `likes` = `likes` + 1 WHERE `post_id` = '$id' limit 1";
			
				mysqli_query($dbconn, $sql_statement_likes);
				
			
					
			header("Location: profile.php");
			
				} else {
					
					$user_id = $_SESSION['USER_ID'];
					$arr[]= $user_id;
					
					$arr2[] = $arr;
					$likes = json_encode($arr2);
					
				}
		

			
			if($type == "bookpost"){
					$sql_statement_likes = "UPDATE `bookposts` set `likes` = `likes` + 1 where `post_id` = '$id' limit 1";
					if (mysqli_query($dbconn, $sql_statement)) {
						
						header("Location: profile.php");
						
					} else {
						echo "Error: " . $sql_statement . "<br>" . mysqli_error($dbconn);//error if connection fails
					}
					
				}
				
}
				
	}
	
