<?php
session_start();



class BookPost
{
	public function create_bookpost($userid, $data)
	{
			
		require('database.php');
		
		$book_id = $_GET['book_id'];
		$bookPost = addslashes($data['bookpost']);
		$username = $_SESSION['username'];
		$pic = $_SESSION['profilePic'];
		
		//inserts new data into database (posts)
		$sql_statement = "INSERT INTO `bookposts` (`bookpost_id`, `date`, `user_id`, `book_id`, `bookpost`, `comments`, `likes`, `username`, `profile_pic`)
		 VALUES (NULL, NULL, '$userid','$book_id', '$bookPost', 0, 0,'$username', '$pic' );";
		
		if (mysqli_query($dbconn, $sql_statement)) {
			
			header("Location:bookList.php");
			
		} else {
			echo "Error: " . $sql_statement . "<br>" . mysqli_error($dbconn);//error if connection fails
		}
			
		}

	public function get_bookposts($book_id)
	{
		require('database.php');

		$sql_statement_posts = "SELECT * FROM `bookposts` WHERE `book_id` = '$book_id'";
		
			$result_posts = mysqli_query($dbconn, $sql_statement_posts);
			if($result_posts) {
				while ($row = mysqli_fetch_assoc($result_posts)) {
					$post = $row['post'];
					$date = $row['date'];
					$pic = $row ['profile_pic'];
				}
			}
		 else {
			echo "error connecting" . mysqli_connect_error();
		}

	}
	}

