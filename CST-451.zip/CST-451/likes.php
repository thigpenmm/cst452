<!-- Getting likes and using "like_post" method to count and add them to database -->
<?php 
require 'database.php';
require 'post.php';


if(isset($_SERVER['HTTP_REFERER'])){
	
	$return_to = "profile.php";
}
else {
	
	if(isset($_GET['type'])&&($_GET['id'])){
		
		if(is_numeric($_GET['id']))	
			{
				$allowed[]= 'post';
				$allowed[]= 'bookpost';
		
				if(in_array($_GET['type'], $allowed)){
					
					$post = new Post();
					$post->like_post($_GET['id'],$_GET['type'], $_SESSION['username']);
				}
			}
		}

header("Location:profile.php");
die;
}
?>