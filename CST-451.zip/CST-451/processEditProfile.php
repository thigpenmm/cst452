<!--  process for editing users in the database -->
<?php
session_start();
require 'database.php';

// creating variables
$id = $_SESSION['USER_ID'];
$firstname = $_GET['firstname'];
$lastname = $_GET['lastname'];
$username = $_GET['username'];
$password = $_GET['password'];
$favebook = $_GET['favebook'];
$selfie = $_GET['selfie'];
$bgpic = $_GET['bgpic'];


//inserts updated data into database (profile)
$sql_statement_profile= "UPDATE `users` SET `firstname`='$firstname', `lastname`='$lastname', `username` ='$username', `password` = '$password', `profile_pic` ='$selfie', `cover_pic` = '$bgpic', `FaveBook` = '$favebook'  WHERE `id`='$id'";

if (mysqli_query($dbconn, $sql_statement_profile)) {

		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $username;
		$_SESSION['firstname'] = $firstname;
		$_SESSION['lastname'] = $lastname;
		$_SESSION['profilePic']= $selfie;
		$_SESSION['coverPic']= $bgpic;
		$_SESSION['favebook']= $favebook;
		header("Location:profile.php");
} else {
	echo "Error: " . $sql_statement_profile . "<br>" . mysqli_error($dbconn);//error if connection fails
}



?>