<!--  Listing of bookposts for the selected book  -->
	<div style=" width: 800px; margin: auto; min-height: 600px;  padding: 20px; font-size: 12;">
	<div style="border: solid thin #2b2929; padding: 10px; background-color: white;"> 
		<form method= "POST">
		<textarea name="bookpost" placeholder="What did you think of this book?"></textarea>
		<input id= "post-button" name="bookpost-button" type="submit">
		</form>
		<br>
		<br>
		</div>
	<?php

	
			$book_id = $_GET['book_id'];
			$sql_statement_bookposts = "SELECT * FROM `bookposts` WHERE `book_id` = '$book_id' order by `date` desc";
			
			$result_bookposts = mysqli_query($dbconn, $sql_statement_bookposts);
			
			
				while($row = mysqli_fetch_array($result_bookposts))
				{
				
				?>
		<br>
		<div id="post">
		<div>
		 <img src="<?php echo $row ['profile_pic']?>" style ="width: 75px; margin-right: 4px">
		</div>
		<div>
		<div style="font-weight: bold; color: #2b2929" > <?php echo $row['username']?>
		<br/>
		<?php echo $row['bookpost']?>
			<br/>
			<a href="" >Like</a> . <a href="">Comment</a> . <?php echo $row['date']?>
						
			</div>
			</div>
		</div>
		<?php } ?>


		
	
