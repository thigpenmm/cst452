	<?php
	require 'database.php';
	
			$book_id = $_POST['book_id'];
			$sql_statement_bookposts = "SELECT * FROM `bookposts` WHERE `book_id` = '$book_id'";
			
			$result_bookposts = mysqli_query($dbconn, $sql_statement_bookposts);
			
			
				while($row = mysqli_fetch_array($result_bookposts))
				{
				
				?>
		<div id="post">
		<div>
		 <img src="<?php echo $row ['profile_pic']?>" style ="width: 75px; margin-right: 4px">
		</div>
		<div>
		<div style="font-weight: bold; color: #2b2929" > <?php echo $row['username']?>
		<br/>
		<?php echo $row['bookpost']?>
			<br/>
			<a href="" >Like</a> . <a href="">Comment</a> . <?php echo $row['date']?>
						
			</div>
			</div>
		</div>
		<?php } ?>
		</div>
	</div>
		
	
