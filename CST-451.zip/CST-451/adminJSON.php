<?php
session_start();
require 'database.php';

if ($_SESSION ['Role'] != '1') {
	echo "You do not have permissions for this page. Please login as an administrator.";
	exit;
}

$sql_users = "SELECT * FROM `users`";
if ($dbconn){
	$result_users = mysqli_query($dbconn, $sql_users);
	if($result_users) {
		while ($row = mysqli_fetch_assoc($result_users)) {
			
			echo "<pre>";
			echo json_encode($row);
			echo "</pre>";
        }
    } else {
        echo "Error with the SQL " . mysqli_error($dbconn);
    }
}   else {
    echo "Error connecting" . mysqli_connect_error();
}



$sql_statement = "SELECT * FROM `posts`";

if ($dbconn){
    $result = mysqli_query($dbconn, $sql_statement);
    if($result) {
        while ($row = mysqli_fetch_assoc($result)) {
        	
        	echo "<pre>";
            echo json_encode($row);
            echo "</pre>";
        }
    } else {
        echo "Error with the SQL " . mysqli_error($dbconn);
    }
}   else {
    echo "Error connecting" . mysqli_connect_error();
}

?>
