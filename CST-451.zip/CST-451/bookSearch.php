<?php
session_start();
require_once 'bookList.php';
$query = $_GET['query'];



// gets value sent over search form
$conn = mysqli_connect("localhost", "root", "root", "bookapp", "3307");
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM books WHERE `title` LIKE '%$query%' OR `author` LIKE '%$query%' OR `genre` LIKE '%$query%'";
$result = $conn->query($sql);

$_POST['book_id'] = $row['book_id'];
$book_id = $_POST['book_id'];

if(mysqli_num_rows($result) > 0)
{

   		 while($row = mysqli_fetch_array($result))
    	{
    		
        ?>        
<head>
<link rel="stylesheet" href="styles.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 <style type="text/css">
  body{ font: 14px sans-serif; text-align: center; }
</style>
</head>
<body style="font-family:Calibri, Helvetica, sans-serif; background color: #d0d8e4;" >
<div class="content">
                <div class="col-md-4">  
                     <form method="GET" action="showBook.php"> 
                          <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">  
                               <img name= "book_pic" src="<?php echo $row["book_pic"]; ?>" class="img-responsive" /><br /> 
                               <input class="hidden" name= "book_id" value="<?php echo $row["book_id"]; ?>"></input>  
                               <h4 name= "title" ><?php echo $row["title"]; ?></h4>  
                               <h4 name= "author"><?php echo $row["author"]; ?></h4>  
                               <input type="submit" name= "selection" style="margin-top:5px;" class=".btn-login" background-color: rgba(44, 62, 80,0.7); value="Post a Review" />  
                          </div>  
                     </form>  
                </div>  
                <?php  
                
                     }  
                }  
     
    
      
 else { echo "0 results"; }

?>
 
               
</div>  
 </form>         
 </div>  
</table>
</body>

