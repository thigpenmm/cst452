<!--  process for editing users on the database -->
<?php
session_start();


require_once 'database.php';


// creating variables
$username = $_POST['username'];
$admin = $_POST['role'];
$password = $_POST['password'];
$id = $_POST['userid'];
$status= $_POST['status'];


//inserts updated data into database (users)
$sql_users = "UPDATE `users` SET `password`='$password',`username`='$username',`role`='$admin', `status`= '$status' WHERE `id`= '$id'";


if (mysqli_query($dbconn, $sql_users)) {
	header("Location:admin.php");
} else {
	header("Location:error.php");
	echo "Error: " . $sql_users . "<br>" . mysqli_error($dbconn);//error if connection fails
}

