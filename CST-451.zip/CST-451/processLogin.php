<!-- process for verifying users are on database and setting the session variables -->
<?php
session_start();

include 'database.php';

if ($dbconn){
	$login = $_POST['username'];
	$password = $_POST['password'];
	
	//echo "Connected to " . $dbname . "as" . $username;
	//echo "<br> login name: " . $attemptedLoginName . "<br>" . $attemptedPassword . "<br>";
	$sql_statement = "SELECT * FROM `users` WHERE `password` = '$password' AND `username`= '$login' AND `status` = 'active'";
	$result = mysqli_query($dbconn, $sql_statement);
	if ($result){
		if (mysqli_num_rows($result) == 1){
			//echo "Login successful<br>";
			$row = mysqli_fetch_assoc($result);
			$_SESSION['username'] = $row['username'];
			$_SESSION['USER_ID'] = $row['id'];
			$_SESSION['firstname'] = $row['firstname'];
			$_SESSION['lastname'] = $row['lastname'];
			$_SESSION['Role'] = $row['role'];
			$_SESSION['profilePic']= $row['profile_pic'];
			$_SESSION['coverPic']= $row['cover_pic'];
			$_SESSION['favebook']= $row['FaveBook'];
			header('Location: profile.php');
		}
		else {
			header('Location: error.php');
			echo "Login unsuccessful<br>";
			exit;
		}
	}
	
	else {
		echo "error" . mysqli_error($dbconn);
		exit;
	}
}
else {
	echo "Error connecting" . mysqli_connect_errno();
	exit;
}
?>
