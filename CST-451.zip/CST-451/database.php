<!--  Database connection page  -->
<?php


define('dbservername', 'localhost');
define('dbusername', 'root');
define('dbpassword', 'root');
define('database', 'bookapp');
define('port','3307');

$dbconn = mysqli_connect(dbservername,dbusername, dbpassword, database, port);


if ($dbconn == false)
{
	die ("Could not connect.". mysqli_connect_error());
}


//function to start a session with the valid user id
function saveUserId($id)
{
	session_start();
	$_SESSION["USER_ID"] = $id;
}

function getUserId()
{
	session_start();
	return $_SESSION["USER_ID"];
}


class Database{
	private $server = "localhost";
	private $username = "root";
	private $password = "root";
	private $database = "bookapp";
	private $port = "3307";
	
	function connect(){
		$dbconn = mysqli_connect($this->server, $this->username, $this->password, $this->database, $this->port);
	}
	
	
	function read(){
		$conn = $this->connect();
		$result = mysqli_query($conn, $query);
		
		if(!result)
		{
			return false;
		}
		else {
			
			$data = false;
			while ($row = mysqli_fetch_assoc($result))
			{
				$data[] = $row;
						
			}
			
			return $data;
		}
	}
	
	function save ($query)
	{
		$conn = $this->connect();
		$result = mysqli_query($conn, $query);
		
		if(!result)
		{
			return false;
		}
		else{
			return true;
		}
	}
	
}
$DB = new Database();

?>