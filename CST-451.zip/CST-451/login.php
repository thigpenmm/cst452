<!--  page to login to application  -->

<html>
<head>
<style>
body {font-family: Calibri, Helvetica, sans-serif;}
* {box-sizing: border-box}

.container {
	width: 500px;
	height: 450px;
	text-align: center;
	margin: 0 auto;
	background-color: rgba(44, 62, 80,0.7);
	margin-top: 160px;
}
input[type="text"],input[type="password"]{
  width: 300px;
  padding: 15px;
  margin: 30px 0 20px 0;
  display: inline-block;
  border: none;
  background: lightGray;
}
 
input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

 
.form-input:nth-child(2)::before{
	content: "\f023";
}
 
.btn-login{
  background-color: #c3c472;
  color: black;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn-register{
  background-color: #72b5c4;
  color: black;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}
button:hover {
  opacity:1;
}

</style>

<title> Login </title>
</head>
<body>
<div class="container">
<form method="POST" action = "processLogin.php">
<div class="form-input">
<h1 style="color:white;"> <br> Book Club Sign In</h1>
<input type="text" name="username" placeholder="Enter your Username"/>
</div>
<div class="form-input">
<input type="password" name="password" placeholder="Enter your Password"/>
</div>
<input type="submit" type="submit" value="LOGIN" class="btn-login"/>
<h3 style="color:white;"> <br> Not a Member?</h3>
</form>
<button class="btn-register"onclick="window.location.href='register.php';">Register Here!</button>

</div>
</body>
</html>
