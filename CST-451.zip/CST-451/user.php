<?php
session_start();
require_once 'database.php';

class User
{
	public function get_data($id)
	{
		require_once 'database.php';
		$id = $_SESSION['USER_ID'];
		
		$query = "SELECT * from `users` where `id` = '$id' limit 1";
		$result_data = mysqli_query($dbconn, $sql_statement_data);
		
		if($result_data) {
			while ($row = mysqli_fetch_assoc($result_posts)) {
				
				$firstname = $row['post'];
				$lastname = $row['date'];
				$username = $row['username'];
				$selfie = $row['profile_pic'];
				$bgpic = $row['cover_pic'];
			}
		}
		else {
			echo "error connecting" . mysqli_connect_error();
		}
		
		mysqli_close($dbconn);
		
		
	}
	
	public function get_user($id)
	{
		$query = "select * from users where userid = '$id' limit 1";
		$DB = new Database();
		$result = $DB->read($query);
		
		if($result)
		{
			return $result[0];
		}
			else 
			{
				return false;
			}
	}

	
	public function get_friends()
	{
	$query = "select * from users where userid != '$id'";
	$DB = new Database();
	$result = $DB->read($query);
	
	if($result)
	{
		return $result;
	}
	else
	{
		return false;
	}
}
}
			
		
	
