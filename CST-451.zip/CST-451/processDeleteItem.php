<?php

require_once 'database.php';

$postToDelete = $_GET['post_id'];


//Admin deleting posts from posts list
$sql_statement = "DELETE FROM `posts` WHERE `post_id` = '$postToDelete'";

if ($dbconn){
    $result = mysqli_query($dbconn, $sql_statement);
    if($result) {
    	
    	header("Location:admin.php");
        echo "Deleted item " . $postToDelete . "<br>";
        
        
        while ($row = mysqli_fetch_assoc($result)) {
           
        }
    } else {
        echo "Error with the SQL " . mysqli_error($dbconn);
    }
}   else {
    echo "Error connecting" . mysqli_connect_error();
}


?>