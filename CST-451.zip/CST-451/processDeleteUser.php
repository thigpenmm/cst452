<?php

require_once 'database.php';


$userToDelete = $_GET['userid'];


// Admin deleting user
$sql_statement_user = "DELETE FROM `users` WHERE `id` = '$userToDelete'";

if ($dbconn){
    $result_user = mysqli_query($dbconn, $sql_statement_user);
    if($result_user) {
        
    	header("Location:admin.php");
        while ($row = mysqli_fetch_assoc($result_user)) {
            
        }
    } else {
    	header("Location:error.php");
        echo "Error with the SQL " . mysqli_error($dbconn);
    }
}   else {
	header("Location:error.php");
    echo "Error connecting" . mysqli_connect_error();
}


?>