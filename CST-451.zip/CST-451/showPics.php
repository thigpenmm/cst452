<!-- process to select and show user's profile and background pics -->
<?php 
	require('database.php');
	$id = $_SESSION['USER_ID'];
	
	$query = "SELECT * from `users` where `id` = '$id' limit 1";
	$result_data = mysqli_query($dbconn, $sql_statement_data);
	
	if($result_data) {
		while ($row = mysqli_fetch_assoc($result_posts)) {
			
			$selfie = $row['profile_pic'];
			$bgpic = $row['cover_pic'];
		}
	}
	else {
		return false;
	}
		
	?>	