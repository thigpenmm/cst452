	<?php
			$sql_statement_posts = "select * from posts order by post_id desc limit 4";
			
			$result_posts = mysqli_query($dbconn, $sql_statement_posts);
			
			
				while($row = mysqli_fetch_array($result_posts))
				{
				
				?>
		<div id="post">
		<div>
		 <img src="<?php echo $row ['profile_pic']?>" style ="width: 75px; margin-right: 4px">
		</div>
		<div>
		<div style="font-weight: bold; color: #2b2929" > <?php echo $row['username']?>
		<br/>
		<?php echo $row['post']?>
			<br/>
			<a href="" >Like</a> . <a href="">Comment</a> . <?php echo $row['date']?>
						
			</div>
			</div>
		</div>
		<?php } ?>
		</div>
	</div>
		
	
