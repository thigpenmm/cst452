<!--  Listing of "friends" from user database  -->
<?php 
session_start();

require('database.php');

$id = $_SESSION['USER_ID'];
$query = "select * from users where id != '$id' limit 3";

$result = mysqli_query($dbconn, $query);

if($result) {
	while ($row = mysqli_fetch_assoc($result)) {
		?>
	
		
		<div id="friends">
		<img id="friends-img" src="<?php echo $row["profile_pic"]?>">
		<br>
		<?php echo $row["firstname"] ." " . $row["lastname"]; ?>
</div> 
	
	<?php }
}
else {
	echo "error connecting" . mysqli_connect_error();
}



?>
 